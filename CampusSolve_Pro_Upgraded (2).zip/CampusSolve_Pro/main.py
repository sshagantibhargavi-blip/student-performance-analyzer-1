"""CampusSolve Pro - Student Performance Analyzer
A desktop student-record manager built with Python's Tkinter and JSON.
"""
from __future__ import annotations
import csv
import json
import os
import tempfile
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from collections import Counter

APP_NAME = "CampusSolve Pro"
DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "students.json")
SUBJECTS = ["Python", "Mathematics", "Physics", "English", "Chemistry"]
GRADES = ["A", "B", "C", "D", "F"]


def grade_for(avg: float) -> str:
    if avg >= 90: return "A"
    if avg >= 80: return "B"
    if avg >= 70: return "C"
    if avg >= 60: return "D"
    return "F"


def normalize_record(raw: dict) -> dict:
    name = str(raw.get("name", "")).strip()
    roll = str(raw.get("roll", "")).strip()
    marks = raw.get("marks", {})
    if not name or not roll or not isinstance(marks, dict):
        raise ValueError("A record is missing its name, roll number, or marks.")
    clean_marks = {}
    for subject in SUBJECTS:
        value = float(marks[subject])
        if not 0 <= value <= 100:
            raise ValueError(f"{subject} marks must be between 0 and 100.")
        clean_marks[subject] = value
    total = sum(clean_marks.values())
    average = total / len(SUBJECTS)
    return {"name": name, "roll": roll, "marks": clean_marks,
            "total": total, "average": average, "grade": grade_for(average)}


def load_students() -> list[dict]:
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, list):
            raise ValueError("The JSON root must be a list.")
        records = [normalize_record(item) for item in data]
        rolls = [s["roll"].casefold() for s in records]
        if len(rolls) != len(set(rolls)):
            raise ValueError("Duplicate roll numbers were found in students.json.")
        return records
    except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
        messagebox.showerror("Data file problem", f"Could not safely load students.json.\n\n{exc}\n\nA new empty session will open; your file is not overwritten until you save a change.")
        return []


def save_students(students: list[dict]) -> None:
    folder = os.path.dirname(DATA_FILE)
    fd, temp_path = tempfile.mkstemp(prefix="students_", suffix=".tmp", dir=folder, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(students, file, indent=4, ensure_ascii=False)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temp_path, DATA_FILE)
    except Exception:
        try: os.remove(temp_path)
        except OSError: pass
        raise


class StudentDialog(tk.Toplevel):
    def __init__(self, parent, title="Add Student", student=None):
        super().__init__(parent)
        self.title(title)
        self.configure(bg="#f4f7fb")
        self.resizable(False, False)
        self.result = None
        self.transient(parent)
        self.grab_set()
        self.vars = {"name": tk.StringVar(value=student["name"] if student else ""),
                     "roll": tk.StringVar(value=student["roll"] if student else "")}
        for subject in SUBJECTS:
            self.vars[subject] = tk.StringVar(value=str(student["marks"][subject]) if student else "")
        body = ttk.Frame(self, padding=20)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="Student information", style="Section.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        fields = [("Student name", "name"), ("Roll number", "roll")] + [(s, s) for s in SUBJECTS]
        for row, (label, key) in enumerate(fields, 1):
            ttk.Label(body, text=label).grid(row=row, column=0, sticky="w", padx=(0, 18), pady=5)
            ttk.Entry(body, textvariable=self.vars[key], width=28).grid(row=row, column=1, sticky="ew", pady=5)
        buttons = ttk.Frame(body)
        buttons.grid(row=len(fields)+1, column=0, columnspan=2, sticky="e", pady=(15, 0))
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(buttons, text="Save student", style="Accent.TButton", command=self.submit).pack(side="right")
        self.bind("<Return>", lambda _e: self.submit())
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_height()) // 2
        self.geometry(f"+{max(0,x)}+{max(0,y)}")

    def submit(self):
        name, roll = self.vars["name"].get().strip(), self.vars["roll"].get().strip()
        if not name or not roll:
            messagebox.showwarning("Missing information", "Enter both student name and roll number.", parent=self); return
        marks = {}
        for subject in SUBJECTS:
            try: value = float(self.vars[subject].get())
            except ValueError:
                messagebox.showwarning("Invalid marks", f"Enter a number for {subject}.", parent=self); return
            if not 0 <= value <= 100:
                messagebox.showwarning("Invalid marks", f"{subject} marks must be from 0 to 100.", parent=self); return
            marks[subject] = value
        self.result = normalize_record({"name": name, "roll": roll, "marks": marks})
        self.destroy()


class CampusSolveApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME + " | Student Performance Analyzer")
        self.geometry("1120x720")
        self.minsize(920, 620)
        self.configure(bg="#f4f7fb")
        self.students = load_students()
        self.search_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Ready")
        self.setup_styles()
        self.build_ui()
        self.refresh()

    def setup_styles(self):
        style = ttk.Style(self)
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure("TFrame", background="#f4f7fb")
        style.configure("TLabel", background="#f4f7fb", foreground="#243247", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 22, "bold"), foreground="#14213d")
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#64748b")
        style.configure("Section.TLabel", font=("Segoe UI", 13, "bold"), foreground="#14213d")
        style.configure("Card.TFrame", background="#ffffff", relief="flat")
        style.configure("CardTitle.TLabel", background="#ffffff", foreground="#64748b", font=("Segoe UI", 9, "bold"))
        style.configure("CardValue.TLabel", background="#ffffff", foreground="#14213d", font=("Segoe UI", 21, "bold"))
        style.configure("Accent.TButton", background="#315efb", foreground="#ffffff", padding=(13, 8), font=("Segoe UI", 9, "bold"))
        style.map("Accent.TButton", background=[("active", "#244bd1")])
        style.configure("Treeview", rowheight=30, font=("Segoe UI", 9), background="#ffffff", fieldbackground="#ffffff")
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#e9eef8", foreground="#243247", padding=8)

    def build_ui(self):
        header = ttk.Frame(self, padding=(24, 20, 24, 10)); header.pack(fill="x")
        ttk.Label(header, text="CampusSolve Pro", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="STUDENT PERFORMANCE ANALYZER  •  Academic insights made simple", style="Sub.TLabel").pack(anchor="w", pady=(3, 0))
        cards = ttk.Frame(self, padding=(24, 10)); cards.pack(fill="x")
        self.card_values = {}
        for key, title in [("count", "TOTAL STUDENTS"), ("average", "CLASS AVERAGE"), ("topper", "TOP PERFORMER"), ("pass", "PASS RATE")]:
            card = ttk.Frame(cards, style="Card.TFrame", padding=15); card.pack(side="left", fill="x", expand=True, padx=(0, 10))
            ttk.Label(card, text=title, style="CardTitle.TLabel").pack(anchor="w")
            value = ttk.Label(card, text="—", style="CardValue.TLabel"); value.pack(anchor="w", pady=(7, 0))
            self.card_values[key] = value
        toolbar = ttk.Frame(self, padding=(24, 12, 24, 8)); toolbar.pack(fill="x")
        ttk.Button(toolbar, text="+ Add student", style="Accent.TButton", command=self.add_student).pack(side="left")
        ttk.Button(toolbar, text="Edit selected", command=self.edit_student).pack(side="left", padx=7)
        ttk.Button(toolbar, text="Delete selected", command=self.delete_student).pack(side="left")
        ttk.Button(toolbar, text="Rankings", command=self.show_rankings).pack(side="left", padx=7)
        ttk.Button(toolbar, text="Subject analysis", command=self.show_subject_analysis).pack(side="left")
        ttk.Button(toolbar, text="Export CSV", command=self.export_csv).pack(side="right")
        searchrow = ttk.Frame(self, padding=(24, 4, 24, 8)); searchrow.pack(fill="x")
        ttk.Label(searchrow, text="Search records:").pack(side="left")
        entry = ttk.Entry(searchrow, textvariable=self.search_var, width=34); entry.pack(side="left", padx=8)
        self.search_var.trace_add("write", lambda *_: self.refresh_table())
        ttk.Button(searchrow, text="Clear", command=lambda: self.search_var.set("")).pack(side="left")
        table_frame = ttk.Frame(self, padding=(24, 0, 24, 10)); table_frame.pack(fill="both", expand=True)
        cols = ("rank", "roll", "name", "total", "average", "grade")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", selectmode="browse")
        headings = {"rank":"RANK", "roll":"ROLL NUMBER", "name":"STUDENT NAME", "total":"TOTAL / 500", "average":"AVERAGE %", "grade":"GRADE"}
        widths = {"rank":65, "roll":150, "name":300, "total":130, "average":130, "grade":90}
        for col in cols:
            self.tree.heading(col, text=headings[col]); self.tree.column(col, width=widths[col], anchor="center" if col not in ("name",) else "w")
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", lambda _e: self.edit_student())
        bottom = ttk.Frame(self, padding=(24, 4, 24, 12)); bottom.pack(fill="x")
        ttk.Label(bottom, textvariable=self.status_var, style="Sub.TLabel").pack(side="left")
        ttk.Label(bottom, text="Data is stored locally in students.json", style="Sub.TLabel").pack(side="right")

    def ranked(self):
        return sorted(self.students, key=lambda s: (-s["average"], s["name"].casefold()))

    def refresh(self):
        count = len(self.students)
        avg = sum(s["average"] for s in self.students) / count if count else 0
        topper = self.ranked()[0]["name"] if count else "—"
        passed = sum(s["grade"] != "F" for s in self.students)
        self.card_values["count"].configure(text=str(count))
        self.card_values["average"].configure(text=f"{avg:.1f}%" if count else "—")
        self.card_values["topper"].configure(text=topper[:15] if count else "—")
        self.card_values["pass"].configure(text=f"{passed/count*100:.0f}%" if count else "—")
        self.refresh_table()

    def refresh_table(self):
        for item in self.tree.get_children(): self.tree.delete(item)
        query = self.search_var.get().strip().casefold()
        for rank, s in enumerate(self.ranked(), 1):
            if query and query not in s["name"].casefold() and query not in s["roll"].casefold(): continue
            self.tree.insert("", "end", iid=s["roll"], values=(rank, s["roll"], s["name"], f"{s['total']:.1f}", f"{s['average']:.2f}", s["grade"]))
        self.status_var.set(f"Showing {len(self.tree.get_children())} of {len(self.students)} student(s)")

    def persist(self):
        try: save_students(self.students)
        except OSError as exc:
            messagebox.showerror("Save failed", f"Could not save student records.\n{exc}"); return False
        return True

    def add_student(self):
        dialog = StudentDialog(self)
        self.wait_window(dialog)
        if dialog.result:
            if any(s["roll"].casefold() == dialog.result["roll"].casefold() for s in self.students):
                messagebox.showwarning("Duplicate roll number", "A student with this roll number already exists."); return
            self.students.append(dialog.result)
            if self.persist(): self.refresh(); messagebox.showinfo("Saved", "Student added successfully.")

    def selected_student(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Select a student", "Please select a student record first."); return None
        roll = selected[0]
        return next((s for s in self.students if s["roll"] == roll), None)

    def edit_student(self):
        old = self.selected_student()
        if not old: return
        dialog = StudentDialog(self, "Edit Student", old)
        self.wait_window(dialog)
        if dialog.result:
            if any(s["roll"].casefold() == dialog.result["roll"].casefold() and s is not old for s in self.students):
                messagebox.showwarning("Duplicate roll number", "Another student already uses this roll number."); return
            index = self.students.index(old); self.students[index] = dialog.result
            if self.persist(): self.refresh()

    def delete_student(self):
        student = self.selected_student()
        if not student: return
        if messagebox.askyesno("Confirm deletion", f"Delete {student['name']} ({student['roll']})? This cannot be undone."):
            self.students.remove(student)
            if self.persist(): self.refresh()

    def show_rankings(self):
        win = tk.Toplevel(self); win.title("Student Rankings"); win.geometry("650x430"); win.configure(bg="#f4f7fb")
        ttk.Label(win, text="Academic leaderboard", style="Title.TLabel").pack(anchor="w", padx=20, pady=18)
        tree = ttk.Treeview(win, columns=("rank", "name", "roll", "average", "grade"), show="headings")
        for c, label, width in [("rank","RANK",70),("name","STUDENT",200),("roll","ROLL NUMBER",130),("average","AVERAGE",110),("grade","GRADE",80)]: tree.heading(c,text=label); tree.column(c,width=width,anchor="center")
        tree.pack(fill="both", expand=True, padx=20, pady=(0,20))
        for i,s in enumerate(self.ranked(),1): tree.insert("","end",values=(i,s['name'],s['roll'],f"{s['average']:.2f}%",s['grade']))

    def show_subject_analysis(self):
        win = tk.Toplevel(self); win.title("Subject Analysis"); win.geometry("760x520"); win.configure(bg="#f4f7fb")
        ttk.Label(win, text="Subject-wise class analysis", style="Title.TLabel").pack(anchor="w", padx=20, pady=18)
        if not self.students:
            ttk.Label(win, text="Add student records to view subject analysis.").pack(padx=20); return
        canvas = tk.Canvas(win, bg="white", highlightthickness=0, height=330)
        canvas.pack(fill="both", expand=True, padx=20, pady=10)
        canvas.update_idletasks()
        width = max(canvas.winfo_width(), 650); base_y = 275; top_y = 35
        canvas.create_line(45, base_y, width-20, base_y, fill="#94a3b8")
        for tick in range(0,101,20):
            y = base_y - (base_y-top_y)*tick/100
            canvas.create_line(45,y,width-20,y,fill="#e5eaf2",dash=(2,3))
            canvas.create_text(28,y,text=str(tick),fill="#64748b")
        gap = (width-90)/len(SUBJECTS); bar_w = min(65,gap*0.55)
        for i,subject in enumerate(SUBJECTS):
            value = sum(s["marks"][subject] for s in self.students)/len(self.students)
            x = 45 + gap*(i+0.5); y = base_y - (base_y-top_y)*value/100
            canvas.create_rectangle(x-bar_w/2,y,x+bar_w/2,base_y,fill="#4776e6",outline="")
            canvas.create_text(x,y-12,text=f"{value:.1f}",fill="#243247",font=("Segoe UI",9,"bold"))
            canvas.create_text(x,base_y+18,text=subject,fill="#475569",font=("Segoe UI",8))
        ttk.Label(win, text="Bars show the class average for each subject (0–100).", style="Sub.TLabel").pack(pady=(0,15))

    def export_csv(self):
        if not self.students:
            messagebox.showinfo("Nothing to export", "There are no student records to export."); return
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files","*.csv")], initialfile="campussolve_report.csv")
        if not path: return
        try:
            with open(path,"w",newline="",encoding="utf-8-sig") as file:
                writer=csv.writer(file)
                writer.writerow(["Rank","Name","Roll Number"]+SUBJECTS+["Total","Average (%)","Grade"])
                for rank,s in enumerate(self.ranked(),1): writer.writerow([rank,s["name"],s["roll"]]+[s["marks"][sub] for sub in SUBJECTS]+[s["total"],round(s["average"],2),s["grade"]])
            messagebox.showinfo("Export complete", f"Report exported successfully:\n{path}")
        except OSError as exc: messagebox.showerror("Export failed", str(exc))


if __name__ == "__main__":
    app = CampusSolveApp()
    app.mainloop()
