CAMPUSSOLVE PRO - STUDENT PERFORMANCE ANALYZER
================================================

OVERVIEW
CampusSolve Pro is a desktop application for managing student marks and reviewing academic performance. It uses Python, Tkinter, JSON and CSV. No third-party packages are required.

FEATURES
1. Add student records with five subject marks.
2. Validate names, unique roll numbers and marks from 0 to 100.
3. View all students in a searchable table.
4. Edit existing student records.
5. Delete records with confirmation.
6. Automatically calculate total, average and grade.
7. Dashboard cards for student count, class average, topper and pass rate.
8. Rank students by average marks.
9. Display subject-wise class-average bar chart.
10. Export ranked student reports to CSV.
11. Store records in students.json with safe, atomic file saving.

SUBJECTS
Python, Mathematics, Physics, English and Chemistry.

GRADE SCALE
A: 90-100 | B: 80-89.99 | C: 70-79.99 | D: 60-69.99 | F: Below 60.

REQUIREMENTS
- Python 3.10 or newer recommended.
- Tkinter (included with most standard Windows Python installations).
- No pip packages are required.

HOW TO RUN IN VS CODE (WINDOWS)
1. Extract the ZIP file.
2. Open the extracted CampusSolve_Pro folder in VS Code.
3. Open Terminal > New Terminal.
4. Run: python --version
5. Run: python main.py
6. Click '+ Add student' and enter a name, roll number and marks.
7. Records are saved automatically in students.json in this folder.

IMPORTANT
- Keep main.py and students.json in the same project folder.
- Back up students.json before manually editing it.
- If you already have a students.json file from your earlier version, copy it into this folder. The app recalculates totals, averages and grades from the five subject marks when loading it.
- This is a local desktop project; it does not require an internet connection.

PROJECT DEMONSTRATION CHECKLIST
1. Add at least three sample students with different marks.
2. Search by name and roll number.
3. Edit one student's marks and show the updated average/grade.
4. Delete a test record after confirmation.
5. Open Rankings and Subject Analysis.
6. Export a CSV report and open it in Excel.
7. Close and reopen the app to demonstrate persistent JSON storage.

ACADEMIC NOTE
The grade estimate depends on the grading scale specified above. Confirm that this scale matches your faculty's requirements before submission. Test with sample data and explain the code during your project evaluation.
